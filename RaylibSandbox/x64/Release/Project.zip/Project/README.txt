Keys:
A S D F J K L ;
All corrospond to keys on the piano.
C D E F G A B C

Holding space will mix in a square wave.

NOTE:
I do not recommend playing more than 3 notes at a time unless you really like the sound of clipping.